#pragma once
#include<iostream>
#include<sstream>
#include<iostream>
#include<vector>
#include<time.h>
#include<SFML/Graphics.hpp>
#include<SFML/System.hpp>
#include<SFML/Window.hpp>
#include<SFML/Network.hpp>
#include<SFML/Audio.hpp>
#include"Enemy.h"
class Player
{
private:
	sf::Sprite sprite;
	sf::Texture texture;

	float movementSpeed;

	//Private functions
	void initSprite();
	void initTexture();

public:
	Player();
	virtual ~Player();

	//Functions
	void move(const float dirX, const float dirY);
	void render(sf::RenderTarget&target);

	void setCrosshairPos(const sf::Vector2f crossPos);
};